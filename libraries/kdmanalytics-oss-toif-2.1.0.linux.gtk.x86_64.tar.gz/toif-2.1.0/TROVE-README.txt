Source code for "Trove for Java" (known as Trove4J), version 3.0.3, can be found on SourceForge at:

http://sourceforge.net/projects/trove4j/files/trove/3.0.3/